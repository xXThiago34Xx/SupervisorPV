name = "xlsx2pdf"

if __name__ == '__main__':
	from cli import main

	exit(main())
